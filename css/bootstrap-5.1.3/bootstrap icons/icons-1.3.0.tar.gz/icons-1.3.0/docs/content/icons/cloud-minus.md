---
title: Cloud minus
categories:
  - Clouds
tags:
  - subtract
---
