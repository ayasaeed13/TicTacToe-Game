---
title: Battery half
categories:
  - Devices
tags:
  - power
  - charge
---
