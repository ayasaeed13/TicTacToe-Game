---
title: Battery charging
categories:
  - Devices
tags:
  - power
  - charge
---
