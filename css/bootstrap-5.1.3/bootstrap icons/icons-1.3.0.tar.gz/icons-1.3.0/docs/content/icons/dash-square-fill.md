---
title: Dash square fill
categories:
  - Alerts, warnings, and signs
tags:
  - minus
---
